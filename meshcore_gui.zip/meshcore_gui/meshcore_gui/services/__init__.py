"""
Business logic services — bot, deduplication and route building.
"""
